java -cp .:JNative.jar HowToUse_Dll $1
