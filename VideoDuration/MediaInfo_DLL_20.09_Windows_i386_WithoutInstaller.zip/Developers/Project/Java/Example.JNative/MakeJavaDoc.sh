mkdir javadoc
javadoc -d ./javadoc -classpath JNative.jar ../../../Source/MediaInfoDLL/MediaInfoDLL.java